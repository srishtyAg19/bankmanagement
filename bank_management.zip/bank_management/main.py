import mysql.connector
mydb=mysql.connector.connect(host='localhost', user='root', password='srishtyAg12@', database='bankmanagement')
def OpenAcc():
    n = input("enter the name:")
    acc = int(input("enter the account no:"))
    dob = int(input("enter the date of birth:"))
    add = input("enter the address:")
    cn = int(input("enter the contact no:"))
    ob = int(input("enter the opening balance:"))

    # Creating tuples
    data1 = (n, acc, dob, add, cn, ob)
    data2 = (n, acc, ob)

    # Corrected SQL queries with commas between placeholders
    sql1 = 'INSERT INTO account VALUES (%s, %s, %s, %s, %s, %s)'
    sql2 = 'INSERT INTO amount VALUES (%s, %s, %s)'

    x = mydb.cursor()
    x.execute(sql1, data1)
    x.execute(sql2, data2)
    mydb.commit()

    print("data entered successfully")
    main()


def deposit_amount():
    amount=int(input("enter the amount you want to deposit:"))
    ac=int(input("enter the account number:"))
    a='select Balance from amount where AccNo=%s'
    data=(a,)
    x=mydb.cursor()
    x.execute(a,data)
    #now I want to fetch a single record
    result=x.fetchone()
    t=result[0]+amount
    sql=('update amount set Balance where AccNo=%s')
    d=(t,ac)
    x.execute(sql,d)
    mydb.commit()
    main()
def withdraw_amount():
    amount = int(input("enter the amount you want to withdraw:"))
    ac = int(input("enter the account number:"))
    a = 'select Balance from amount where AccNo=%s'
    data = (a,)
    x = mydb.cursor()
    x.execute(a, data)
    # now I want to fetch a single record
    result = x.fetchone()
    t = result[0] - amount
    sql = ('update amount set Balance where AccNo=%s')
    d = (t, ac)
    x.execute(sql, d)
    mydb.commit()
    main()
def balance_enquiry():
    ac=input("enter the accno:")
    a= 'select * from amount where AccNo:%s'
    data=(ac,)
    x=mydb.cursor()
    x.execute(a,data)
    result=x.fetchone()
    print("balance for account: ", ac, "is", result[-1])
    main()
def display_customer_details():
    ac = input("enter the accno:")
    a = 'select * from account where AccNo:%s'
    data = (ac,)
    x = mydb.cursor()
    x.execute(a, data)
    result = x.fetchone()
    for i in result:
        print(i)
    main()
def     close_an_account():
    ac = input("enter the accno:")
    sql1='delete from account where AccNo:%s'
    sql2='delete from amount where AccNo:%s'
    data=(ac,)
    x=mydb.cursor()
    x.execute(sql2, data)
    mydb.commit()
    main()

def main():
    print('''
    1. open new account 
    2. deposit amount
    3. withdraw amount
    4. balance enquiry 
    5. display customer details
    6. close an account 
    ''')
    choice=input("enter the task you want to perform:")
    if(choice=='1'):
        OpenAcc()
    elif(choice=='2.'):
        deposit_amount()
    elif(choice=='3.'):
        withdraw_amount()
    elif(choice=='4.'):
        balance_enquiry()
    elif(choice=='5.')    :
        display_customer_details()
    elif(choice=='6.'):
        close_an_account()
    else:
        print("invalid choice")
        main()
main()